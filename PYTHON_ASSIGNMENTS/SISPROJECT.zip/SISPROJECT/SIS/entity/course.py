class Course:
    def __init__(self, course_id, course_name, credits, teacher_id=None):
        self.course_id = course_id
        self.course_name = course_name
        self.credits = credits
        self.teacher_id = teacher_id
        self.enrollments = []

    def __str__(self) :
            return f"Course ID: {self.course_id}, Name: {self.course_name}, Credits: {self.credits}, Teacher ID: {self.teacher_id}"

    def assign_teacher(self, teacher):
        self.teacher = teacher
        teacher.assigned_courses.append(self)

    def update_course_info(self, course_code, course_name, teacher=None):
        self.course_name = course_name
        self.course_code = course_code
        if teacher:
            self.teacher = teacher

    def display_course_info(self):
        teacher_info = f"{self.teacher.first_name} {self.teacher.last_name}" if self.teacher else "Not Assigned"
        print(f"Course ID: {self.course_id} | Name: {self.course_name} | Instructor: {teacher_info}")
