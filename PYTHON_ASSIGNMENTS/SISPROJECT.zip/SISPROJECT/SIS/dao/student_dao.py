import pyodbc


from SIS.entity.teacher import Teacher
from SIS.util.DBConnUtil import get_connection
from SIS.entity.student import Student
from SIS.entity.course import Course

class StudentDAO:
    def __init__(self) :
        self.conn = pyodbc.connect(
            'DRIVER={SQL Server};SERVER=localhost;DATABASE=StudentDB;Trusted_Connection=yes;'
        )
        self.cursor = self.conn.cursor()
    def __init__(self):
        self.conn = get_connection()
        self.cursor = self.conn.cursor()

    def get_student_by_id(self, student_id):
        self.cursor.execute("SELECT * FROM Students WHERE student_id = ?", (student_id,))
        row = self.cursor.fetchone()
        if row:
            return Student(row.student_id, row.first_name, row.last_name, row.date_of_birth, row.email,
                           row.phone_number)
        return None

    def add_student(self, student):
        query = """
            INSERT INTO Students (first_name, last_name, date_of_birth, email, phone_number)
            VALUES (?, ?, ?, ?, ?)
        """
        self.cursor.execute(query, (
            student.first_name,
            student.last_name,
            student.date_of_birth,
            student.email,
            student.phone_number
        ))
        self.conn.commit()

    def add_enrollment(self, student, course, enrollment_date):
        self.cursor.execute(
            "SELECT COUNT(*) FROM Enrollments WHERE student_id = ? AND course_id = ?",
            (student.student_id, course.course_id)
        )
        if self.cursor.fetchone()[0] > 0:
            print("⚠️ Student already enrolled in this course.")
            return

        self.cursor.execute(
            "INSERT INTO Enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)",
            (student.student_id, course.course_id, enrollment_date)
        )
        self.conn.commit()
        print(f"✅ Enrolled {student.first_name} in {course.course_name}")

    def assign_course_to_teacher(self, course, teacher):
        self.cursor.execute(
            "UPDATE Courses SET teacher_id = ? WHERE course_id = ?",
            (teacher.teacher_id, course.course_id)
        )
        self.conn.commit()
        print(f"✅ Assigned {teacher.first_name} to teach {course.course_name}")

    def add_payment(self, student, amount, payment_date):
        self.cursor.execute(
            "INSERT INTO Payments (student_id, amount, payment_date) VALUES (?, ?, ?)",
            (student.student_id, amount, payment_date)
        )
        self.conn.commit()
        print(f"💰 Recorded payment of ₹{amount} for {student.first_name}")

    def get_enrollments_for_student(self, student):
        self.cursor.execute(
            """
            SELECT e.enrollment_id, c.course_name, e.enrollment_date
            FROM Enrollments e
            JOIN Courses c ON e.course_id = c.course_id
            WHERE e.student_id = ?
            """,
            (student.student_id,)
        )
        return self.cursor.fetchall()

    def get_all_students(self):
        self.cursor.execute("SELECT * FROM Students")
        rows = self.cursor.fetchall()
        students = []
        for row in rows:
            student = Student(row.student_id, row.first_name, row.last_name, row.date_of_birth, row.email,
                              row.phone_number)
            students.append(student)
        return students



    def get_all_courses(self) :
        self.cursor.execute("SELECT * FROM Courses")
        rows = self.cursor.fetchall()

        courses = []
        for row in rows :
            # Update constructor based on your actual Course class
            course = Course(row.course_id, row.course_name, None, row.teacher_id)  # Assuming credits aren't needed
            courses.append(course)
        return courses

    def get_course_by_id(self, course_id) :
        self.cursor.execute("SELECT * FROM Courses WHERE course_id = ?", (course_id,))
        row = self.cursor.fetchone()
        if row :
            return Course(row.course_id, row.course_name, None, row.teacher_id)
        return None

    def get_all_teacher(self) :
        self.cursor.execute("SELECT * FROM Teacher")
        rows = self.cursor.fetchall()
        teachers = []
        for row in rows :
            teacher = Teacher(row.teacher_id, row.first_name, row.last_name, row.email)
            teachers.append(teacher)
        return teachers

    def add_teacher(self, teacher) :
        query = """
                INSERT INTO Teachers (teacher_id, first_name, last_name, email)
                VALUES (?, ?, ?, ?) \
                """
        self.cursor.execute(query, (
            teacher.teacher_id,
            teacher.first_name,
            teacher.last_name,
            teacher.email
        ))
        self.conn.commit()  # ✅ This line ensures the changes are saved in DB






