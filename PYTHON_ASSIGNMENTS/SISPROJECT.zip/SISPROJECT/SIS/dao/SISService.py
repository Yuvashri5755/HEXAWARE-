import pyodbc

from SIS.entity.enrollment import Enrollment
from SIS.exception.DuplicateEnrollmentException import DuplicateEnrollmentException


class SISService:
    def __init__(self) :
        self.conn = pyodbc.connect(
            'DRIVER={SQL Server};SERVER=localhost;DATABASE=StudentDB;Trusted_Connection=yes;'
        )
        self.cursor = self.conn.cursor()
    def __init__(self):
        self.students = {}
        self.courses = {}
        self.enrollments = []
        self.payments = []
        self.teachers = {}

    def add_student(self, student):
        self.students[student.student_id] = student

    def add_course(self, course):
        self.courses[course.course_id] = course

    def add_teacher(self, teacher):
        self.teachers[teacher.teacher_id] = teacher

    def get_all_teachers(self):
        return list(self.teachers.values())

    def enroll_student(self, student, course, enrollment_id, date):
        # Defensive check to make sure we don't duplicate enrollments in the same session
        for e in self.enrollments:
            if e.student.student_id == student.student_id and e.course.course_id == course.course_id:
                raise DuplicateEnrollmentException("Already enrolled in this course.")

        enrollment = Enrollment(enrollment_id, student, course, date)
        self.enrollments.append(enrollment)
        print(f"✅ Enrolled {student.first_name} in {course.course_name}")
