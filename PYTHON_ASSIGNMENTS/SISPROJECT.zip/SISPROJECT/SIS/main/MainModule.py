from SIS.dao.student_dao import StudentDAO
from SIS.dao.SISService import SISService
from SIS.entity.student import Student
from SIS.entity.course import Course
from SIS.entity.teacher import Teacher
from SIS.exception.DuplicateEnrollmentException import DuplicateEnrollmentException
from datetime import datetime

def main():
    student_dao = StudentDAO()
    sis_service = SISService()

    print("Welcome to Student Information System (SIS)")
    while True:
        print("\n==== MENU ====")
        print("1. Add New Student")
        print("2. View All Students")
        print("3. Add Course")
        print("4. View All Courses")
        print("5. Add Teacher")
        print("6. View All Teachers")
        print("7. Enroll Student in Course")
        print("8. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            fname = input("First Name: ")
            lname = input("Last Name: ")
            dob = input("Date of Birth (YYYY-MM-DD): ")
            email = input("Email: ")
            phone = input("Phone: ")
            student = Student(None, fname, lname, dob, email, phone)
            student_dao.add_student(student)
            print("✅ Student added successfully.")

        elif choice == "2":
            students = student_dao.get_all_students()
            if not students:
                print("No students found.")
            for s in students:
                print(s)  # Ensure __str__ method is implemented in Student class

        elif choice == "3":
            course_id = int(input("Course ID: "))
            name = input("Course Name: ")
            code = input("Course Code: ")
            course = Course(course_id, name, code, None)
            sis_service.courses[course_id] = course
            print("✅ Course added successfully.")

        elif choice == "4":
            courses = student_dao.get_all_courses()
            if not courses:
                print("No courses found.")
            for c in courses:
                print(c)  # Ensure __str__ method is implemented in Course class

        elif choice == "5":
            teacher_id = int(input("Teacher ID: "))
            first_name = input("First Name: ")
            last_name = input("Last Name: ")
            email = input("Email: ")
            teacher = Teacher(teacher_id, first_name, last_name, email)
            sis_service.add_teacher(teacher)
            print("✅ Teacher added successfully.")

        elif choice == "6":
            teachers = sis_service.get_all_teachers()

            if not teachers :
                print("No teachers found.")
            for t in teachers :
                print(t)  # Ensure __str__ method is implemented in Teacher class

            teachers = student_dao.get_all_teacher()

            for teacher in teachers :
                print(
                    f"Teacher ID: {teacher.teacher_id}, Name: {teacher.first_name} {teacher.last_name}, Email: {teacher.email}")

            if not teachers:
                print("No teachers found.")


        elif choice == "7":
            try:
                student_id = int(input("Student ID: "))
                course_id = int(input("Course ID: "))
                enrollment_id = int(input("Enrollment ID: "))
                date_str = input("Enrollment Date (YYYY-MM-DD): ")
                date = datetime.strptime(date_str, "%Y-%m-%d").date()
                student = student_dao.get_student_by_id(student_id)
                course = student_dao.get_course_by_id(course_id)

                if not student:
                    print("❌ Student not found.")
                    continue
                if not course:
                    print("❌ Course not found.")
                    continue

                sis_service.enroll_student(student, course, enrollment_id, date)
                print("✅ Enrollment successful.")
            except DuplicateEnrollmentException as e:
                print("Error:", e)
            except Exception as e:
                print("Error:", e)

        elif choice == "8":
            print("👋 Exiting... Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
