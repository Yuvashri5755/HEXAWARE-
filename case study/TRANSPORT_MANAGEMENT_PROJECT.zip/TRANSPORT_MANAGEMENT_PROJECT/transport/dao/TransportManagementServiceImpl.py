
from transport.dao.TransportManagementService import TransportManagementService
from transport.entity.Vehicle import Vehicle
from transport.entity.Booking import Booking
from transport.entity.Route import Route
from transport.entity.Passenger import Passenger
from transport.entity.Trip import Trip
from transport.util.DBConnUtil import get_connection
from transport.exception.VehicleNotFoundException import VehicleNotFoundException
from transport.exception.BookingNotFoundException import BookingNotFoundException

from typing import List

class TransportManagementServiceImpl(TransportManagementService):

    def addVehicle(self, vehicle: Vehicle) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        query = "INSERT INTO Vehicles (Model, Capacity, Type, Status) VALUES (?, ?, ?, ?)"
        cursor.execute(query, vehicle.model, vehicle.capacity, vehicle.type, vehicle.status)
        conn.commit()
        return True

    def updateVehicle(self, vehicle: Vehicle) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        query = "UPDATE Vehicles SET Model=?, Capacity=?, Type=?, Status=? WHERE VehicleID=?"
        cursor.execute(query, vehicle.model, vehicle.capacity, vehicle.type, vehicle.status, vehicle.vehicle_id)
        if cursor.rowcount == 0:
            raise VehicleNotFoundException()
        conn.commit()
        return True

    def deleteVehicle(self, vehicle_id: int) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        query = "DELETE FROM Vehicles WHERE VehicleID=?"
        cursor.execute(query, vehicle_id)
        if cursor.rowcount == 0:
            raise VehicleNotFoundException()
        conn.commit()
        return True

    def scheduleTrip(self, vehicle_id: int, route_id: int, departure_date: str, arrival_date: str) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        query = """
            INSERT INTO Trips (VehicleID, RouteID, DepartureDate, ArrivalDate, Status)
            VALUES (?, ?, ?, ?, 'Scheduled')
        """
        cursor.execute(query, vehicle_id, route_id, departure_date, arrival_date)
        conn.commit()
        return True

    def cancelTrip(self, trip_id: int) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        query = "UPDATE Trips SET Status='Cancelled' WHERE TripID=?"
        cursor.execute(query, trip_id)
        if cursor.rowcount == 0:
            return False
        conn.commit()
        return True

    def bookTrip(self, trip_id: int, passenger_id: int, booking_date: str) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        query = """
            INSERT INTO Bookings (TripID, PassengerID, BookingDate, Status)
            VALUES (?, ?, ?, 'Confirmed')
        """
        cursor.execute(query, trip_id, passenger_id, booking_date)
        conn.commit()
        return True

    def cancelBooking(self, booking_id: int) -> bool:
        conn = get_connection()
        cursor = conn.cursor()
        query = "UPDATE Bookings SET Status='Cancelled' WHERE BookingID=?"
        cursor.execute(query, booking_id)
        if cursor.rowcount == 0:
            raise BookingNotFoundException()
        conn.commit()
        return True

    def getBookingsByPassenger(self, passenger_id: int) -> List[Booking]:
        conn = get_connection()
        cursor = conn.cursor()
        query = "SELECT * FROM Bookings WHERE PassengerID=?"
        cursor.execute(query, passenger_id)
        rows = cursor.fetchall()
        bookings = [Booking(*row) for row in rows]
        return bookings

    def getBookingsByTrip(self, trip_id: int) -> List[Booking]:
        conn = get_connection()
        cursor = conn.cursor()
        query = "SELECT * FROM Bookings WHERE TripID=?"
        cursor.execute(query, trip_id)
        rows = cursor.fetchall()
        bookings = [Booking(*row) for row in rows]
        return bookings

    def getAllVehicles(self) :
        try :
            connection = get_connection()  # Assuming you have this method to establish DB connection
            cursor = connection.cursor()

            query = "SELECT * FROM Vehicles"  # SQL query to select all vehicles
            cursor.execute(query)

            vehicles = []
            for row in cursor.fetchall() :
                vehicle = Vehicle(vehicle_id=row[0], model=row[1], capacity=row[2], type=row[3], status=row[4])
                vehicles.append(vehicle)

            cursor.close()
            connection.close()
            return vehicles

        except Exception as e :
            print(f"Error while fetching vehicles: {e}")
            return []

    def addRoute(self, route: Route) -> bool :
        try :
            connection = get_connection()
            cursor = connection.cursor()

            query = """
                    INSERT INTO Routes (StartDestination, EndDestination, Distance)
                    VALUES (?, ?, ?) \
                    """
            cursor.execute(query, (route.start_destination, route.end_destination, route.distance))
            connection.commit()

            cursor.close()
            connection.close()
            return True
        except Exception as e :
            print(f"Error while adding route: {e}")
            return False

    def getAllRoutes(self) -> List[Route] :
        try :
            connection = get_connection()
            cursor = connection.cursor()

            query = "SELECT * FROM Routes"
            cursor.execute(query)

            routes = []
            for row in cursor.fetchall() :
                route = Route(route_id=row[0], start_destination=row[1], end_destination=row[2], distance=row[3])
                routes.append(route)

            cursor.close()
            connection.close()
            return routes
        except Exception as e :
            print(f"Error while fetching routes: {e}")
            return []

    def addPassenger(self, passenger: Passenger) -> bool :
        try :
            connection = get_connection()
            cursor = connection.cursor()

            query = """
                    INSERT INTO Passengers (FirstName, Gender, Age, Email, PhoneNumber)
                    VALUES (?, ?, ?, ?, ?) \
                    """
            cursor.execute(query, (
                passenger.first_name,
                passenger.gender,
                passenger.age,
                passenger.email,
                passenger.phone_number
            ))
            connection.commit()

            cursor.close()
            connection.close()
            return True
        except Exception as e :
            print(f"Error while adding passenger: {e}")
            return False

    def getAllTrips(self) :
        try :
            conn = get_connection()
            cursor = conn.cursor()

            query = "SELECT * FROM Trips"
            cursor.execute(query)
            rows = cursor.fetchall()

            trips = []
            for row in rows :
                trip = Trip(
                    trip_id=row[0],
                    vehicle_id=row[1],
                    route_id=row[2],
                    departure_date=row[3],
                    arrival_date=row[4],
                    status=row[5]
                )
                trips.append(trip)

            cursor.close()
            conn.close()
            return trips
        except Exception as e :
            print(f"Error while fetching trips: {e}")
            return []

    def getAllBookings(self) :
        conn = get_connection()
        cursor = conn.cursor()
        query = "SELECT * FROM Bookings"
        cursor.execute(query)
        rows = cursor.fetchall()
        bookings = [Booking(*row) for row in rows]
        cursor.close()
        conn.close()
        return bookings

