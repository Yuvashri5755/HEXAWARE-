# dao/TransportManagementService.py

from abc import ABC, abstractmethod
from typing import List
from transport.entity.Vehicle import Vehicle
from transport.entity.Booking import Booking

class TransportManagementService(ABC):

    @abstractmethod
    def addVehicle(self, vehicle: Vehicle) -> bool:
        pass

    @abstractmethod
    def updateVehicle(self, vehicle: Vehicle) -> bool:
        pass

    @abstractmethod
    def deleteVehicle(self, vehicle_id: int) -> bool:
        pass

    @abstractmethod
    def scheduleTrip(self, vehicle_id: int, route_id: int, departure_date: str, arrival_date: str) -> bool:
        pass

    @abstractmethod
    def cancelTrip(self, trip_id: int) -> bool:
        pass

    @abstractmethod
    def bookTrip(self, trip_id: int, passenger_id: int, booking_date: str) -> bool:
        pass

    @abstractmethod
    def cancelBooking(self, booking_id: int) -> bool:
        pass


    @abstractmethod
    def getBookingsByPassenger(self, passenger_id: int) -> List[Booking]:
        pass

    @abstractmethod
    def getBookingsByTrip(self, trip_id: int) -> List[Booking]:
        pass

