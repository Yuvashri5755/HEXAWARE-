
class VehicleNotFoundException(Exception):
    def __init__(self, message="Vehicle not found in the database."):
        super().__init__(message)
