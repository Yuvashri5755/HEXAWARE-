

class BookingNotFoundException(Exception):
    def __init__(self, message="Booking not found in the database."):
        super().__init__(message)
