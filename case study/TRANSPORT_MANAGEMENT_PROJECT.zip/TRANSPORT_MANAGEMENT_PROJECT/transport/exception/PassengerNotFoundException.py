class PassengerNotFoundException(Exception):
    def __init__(self, message="Passenger not found."):
        super().__init__(message)
