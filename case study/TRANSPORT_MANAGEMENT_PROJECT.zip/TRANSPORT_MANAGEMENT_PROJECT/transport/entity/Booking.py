class Booking:
    def __init__(self, booking_id, trip_id, passenger_id, booking_date, status):
        self.booking_id = booking_id
        self.trip_id = trip_id
        self.passenger_id = passenger_id
        self.booking_date = booking_date
        self.status = status

    def __str__(self):
        return (f"BookingID: {self.booking_id}, TripID: {self.trip_id}, "
                f"PassengerID: {self.passenger_id}, BookingDate: {self.booking_date}, Status: {self.status}")

    # Getters
    def get_booking_id(self):
        return self.__booking_id

    def get_trip_id(self):
        return self.__trip_id

    def get_passenger_id(self):
        return self.__passenger_id

    def get_booking_date(self):
        return self.__booking_date

    def get_status(self):
        return self.__status

    # Setters
    def set_booking_id(self, booking_id):
        self.__booking_id = booking_id

    def set_trip_id(self, trip_id):
        self.__trip_id = trip_id

    def set_passenger_id(self, passenger_id):
        self.__passenger_id = passenger_id

    def set_booking_date(self, booking_date):
        self.__booking_date = booking_date

    def set_status(self, status):
        self.__status = status
