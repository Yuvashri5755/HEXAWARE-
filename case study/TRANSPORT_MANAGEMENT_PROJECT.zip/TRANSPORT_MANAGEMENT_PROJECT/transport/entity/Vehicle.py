
class Vehicle :
    def __init__(self, vehicle_id=None, model=None, capacity=None, type=None, status=None) :
            self.vehicle_id = vehicle_id
            self.model = model
            self.capacity = capacity
            self.type = type
            self.status = status

    def __str__(self) :
            return f"Vehicle(ID={self.vehicle_id}, Model={self.model}, Capacity={self.capacity}, Type={self.type}, Status={self.status})"

    # Getters
    def get_vehicle_id(self):
        return self.__vehicle_id

    def get_model(self):
        return self.__model

    def get_capacity(self):
        return self.__capacity

    def get_type(self):
        return self.__type

    def get_status(self):
        return self.__status

    # Setters
    def set_vehicle_id(self, vehicle_id):
        self.__vehicle_id = vehicle_id

    def set_model(self, model):
        self.__model = model

    def set_capacity(self, capacity):
        self.__capacity = capacity

    def set_type(self, type):
        self.__type = type

    def set_status(self, status):
        self.__status = status
