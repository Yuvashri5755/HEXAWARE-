from transport.dao.TransportManagementServiceImpl import TransportManagementServiceImpl
from transport.entity.Vehicle import Vehicle
from transport.entity.Booking import Booking
from transport.entity.Passenger import Passenger
from transport.entity.Route import Route
from transport.exception.VehicleNotFoundException import VehicleNotFoundException
from transport.exception.BookingNotFoundException import BookingNotFoundException
from transport.exception.PassengerNotFoundException import PassengerNotFoundException

def main():
    service = TransportManagementServiceImpl()

    while True:
        print("\n=== Transport Management Menu ===")
        print("1. Add Vehicle")
        print("2. View Vehicles")
        print("3. Update Vehicle")
        print("4. Delete Vehicle")
        print("5. Add Route")
        print("6. View Routes")
        print("7. Schedule Trip")
        print("8. View Trip")
        print("9. Add Passenger")
        print("10. View Passengers")
        print("11. Add Booking")
        print("12. View Bookings")
        print("13. Exit")

        choice = input("Enter choice: ")

        try:
            if choice == '1':
                model = input("Model: ")
                capacity = float(input("Capacity: "))
                type = input("Type: ")
                status = input("Status: ")
                vehicle = Vehicle(model=model, capacity=capacity, type=type, status=status)
                result = service.addVehicle(vehicle)
                print("Vehicle added!" if result else "Failed to add vehicle.")

            elif choice == '2':
                vehicles = service.getAllVehicles()
                for v in vehicles:
                    print(v)

            elif choice == '3':
                vehicle_id = int(input("Vehicle ID: "))
                model = input("New Model: ")
                capacity = float(input("New Capacity: "))
                type = input("New Type: ")
                status = input("New Status: ")
                vehicle = Vehicle(vehicle_id, model, capacity, type, status)
                result = service.updateVehicle(vehicle)
                print("Vehicle updated!" if result else "Update failed.")

            elif choice == '4':
                vehicle_id = int(input("Vehicle ID to delete: "))
                result = service.deleteVehicle(vehicle_id)
                print("Vehicle deleted!" if result else "Delete failed.")

            elif choice == '5' :
                start = input("Start Destination: ")
                end = input("End Destination: ")
                distance = float(input("Distance (km): "))
                route = Route(start_destination=start, end_destination=end, distance=distance)
                result = service.addRoute(route)
                print("Route added!" if result else "Failed to add route.")

            elif choice == '6' :
                routes = service.getAllRoutes()
                for r in routes :
                    print(r)

            elif choice == '7':
                vehicle_id = int(input("Vehicle ID for the trip: "))
                route_id = int(input("Route ID: "))
                departure_date = input("Departure Date (YYYY-MM-DD): ")
                arrival_date = input("Arrival Date (YYYY-MM-DD): ")
                result = service.scheduleTrip(vehicle_id, route_id, departure_date, arrival_date)
                print("Trip scheduled!" if result else "Failed to schedule trip.")

            elif choice == '8' :
                trips = service.getAllTrips()
                for t in trips :
                    print(t)

            elif choice == '9' :
                first_name = input("First Name: ")
                gender = input("Gender: ")
                age = int(input("Age: "))
                email = input("Email: ")
                phone = input("Phone Number: ")
                passenger = Passenger(first_name=first_name, gender=gender, age=age, email=email, phone_number=phone)
                result = service.addPassenger(passenger)
                print("Passenger added!" if result else "Failed to add passenger.")

            elif choice == '10' :
                passengers = service.getAllPassengers()
                for p in passengers :
                    print(p)

            elif choice == '11':
                trip_id = int(input("Trip ID for the booking: "))
                passenger_id = int(input("Passenger ID: "))
                booking_date = input("Booking Date (YYYY-MM-DD): ")
                result = service.bookTrip(trip_id, passenger_id, booking_date)
                print("Booking added!" if result else "Failed to add booking.")

            elif choice == '12':
                view_choice = input("View all bookings (y/n)? ")
                if view_choice.lower() == 'y':
                    bookings = service.getAllBookings()
                    for booking in bookings:
                        print(booking)
                else:
                    passenger_id = int(input("Enter Passenger ID to view bookings: "))
                    bookings = service.getBookingsByPassenger(passenger_id)
                    for booking in bookings:
                        print(booking)


            elif choice == '13':
                print("Thank you, Exiting...")
                break

            else:
                print("Invalid choice.")

        except VehicleNotFoundException as ve:
            print(f"Error: {ve}")
        except BookingNotFoundException as be:
            print(f"Error: {be}")
        except PassengerNotFoundException as pe:
            print(f"Error: {pe}")
        except Exception as e:
            print(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()
