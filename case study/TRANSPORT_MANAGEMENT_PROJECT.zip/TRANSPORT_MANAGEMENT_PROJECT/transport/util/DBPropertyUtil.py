

import configparser

def get_db_properties(file_name='db.properties'):
    config = configparser.ConfigParser()
    config.read(file_name)
    return config['DATABASE']
