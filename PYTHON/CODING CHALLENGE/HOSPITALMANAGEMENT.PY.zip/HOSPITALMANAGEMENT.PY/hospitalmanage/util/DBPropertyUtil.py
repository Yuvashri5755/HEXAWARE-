import configparser

class DBPropertyUtil:
    @staticmethod
    def getPropertyString(filename):
        config = configparser.ConfigParser()
        config.read(filename)
        server = config['DATABASE']['server']
        database = config['DATABASE']['database']
        username = config['DATABASE']['username']
        password = config['DATABASE']['password']
        return f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}"
