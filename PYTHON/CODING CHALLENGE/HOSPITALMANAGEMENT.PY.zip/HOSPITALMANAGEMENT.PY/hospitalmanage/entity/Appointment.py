class Appointment:
    def __init__(self, appointmentId=0, patientId=0, doctorId=0, appointmentDate="", description=""):
        self.appointmentId = appointmentId
        self.patientId = patientId
        self.doctorId = doctorId
        self.appointmentDate = appointmentDate
        self.description = description

    def __str__(self):
        return (f"Appointment ID: {self.appointmentId}, Patient ID: {self.patientId}, "
                f"Doctor ID: {self.doctorId}, Date: {self.appointmentDate}, Description: {self.description}")
