from hospitalmanage.dao.IHospitalService import IHospitalService
from hospitalmanage.util.DBConnUtil import DBConnUtil
from hospitalmanage.entity.Appointment import Appointment
from hospitalmanage.exception.PatientNumberNotFoundException import PatientNumberNotFoundException

class HospitalServiceImpl(IHospitalService):
    def getAppointmentById(self, appointmentId):
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Appointment WHERE appointmentId = ?", appointmentId)
        row = cursor.fetchone()
        if row:
            return Appointment(*row)
        return None

    def getAppointmentsForPatient(self, patientId):
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Appointment WHERE patientId = ?", patientId)
        rows = cursor.fetchall()
        if not rows:
            raise PatientNumberNotFoundException()
        return [Appointment(*row) for row in rows]

    def getAppointmentsForDoctor(self, doctorId):
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Appointment WHERE doctorId = ?", doctorId)
        return [Appointment(*row) for row in cursor.fetchall()]

    def scheduleAppointment(self, appointment):
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Appointment VALUES (?, ?, ?, ?, ?)",
                       appointment.appointmentId, appointment.patientId,
                       appointment.doctorId, appointment.appointmentDate,
                       appointment.description)
        conn.commit()
        return True

    def updateAppointment(self, appointment):
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("UPDATE Appointment SET patientId=?, doctorId=?, appointmentDate=?, description=? WHERE appointmentId=?",
                       appointment.patientId, appointment.doctorId, appointment.appointmentDate, appointment.description, appointment.appointmentId)
        conn.commit()
        return True

    def cancelAppointment(self, appointmentId):
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM Appointment WHERE appointmentId=?", appointmentId)
        conn.commit()
        return True

    def addPatient(self, patient) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Patient VALUES (?, ?, ?, ?, ?, ?, ?)",
                       patient.patientId, patient.firstName, patient.lastName,
                       patient.dateOfBirth, patient.gender,
                       patient.contactNumber, patient.address)
        conn.commit()
        return True

    def addDoctor(self, doctor) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Doctor VALUES (?, ?, ?, ?, ?)",
                       doctor.doctorId, doctor.firstName, doctor.lastName,
                       doctor.specialization, doctor.contactNumber)
        conn.commit()
        return True

    def listAllPatients(self) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Patient")
        return cursor.fetchall()

    def listAllDoctors(self) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Doctor")
        return cursor.fetchall()

    def listAllAppointments(self) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Appointment")
        return cursor.fetchall()

    def getPatientById(self, patientId) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Patient WHERE patientId = ?", patientId)
        row = cursor.fetchone()
        if row :
            return row
        return None

    def updatePatient(self, patient) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE Patient SET firstName=?, lastName=?, dateOfBirth=?, gender=?, contactNumber=?, address=? WHERE patientId=?",
            patient.firstName, patient.lastName, patient.dateOfBirth, patient.gender,
            patient.contactNumber, patient.address, patient.patientId)
        conn.commit()
        return True

    def deletePatient(self, patientId) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM Patient WHERE patientId=?", patientId)
        conn.commit()
        return True

    def getDoctorById(self, doctorId) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Doctor WHERE doctorId = ?", doctorId)
        row = cursor.fetchone()
        if row :
            return row
        return None

    def updateDoctor(self, doctor) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("UPDATE Doctor SET firstName=?, lastName=?, specialization=?, contactNumber=? WHERE doctorId=?",
                       doctor.firstName, doctor.lastName, doctor.specialization, doctor.contactNumber, doctor.doctorId)
        conn.commit()
        return True

    def deleteDoctor(self, doctorId) :
        conn = DBConnUtil.getConnection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM Doctor WHERE doctorId=?", doctorId)
        conn.commit()
        return True
