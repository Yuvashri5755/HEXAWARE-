from hospitalmanage.dao.HospitalServiceImpl import HospitalServiceImpl
from hospitalmanage.entity.Patient import Patient
from hospitalmanage.entity.Doctor import Doctor
from hospitalmanage.entity.Appointment import Appointment
from hospitalmanage.exception.PatientNumberNotFoundException import PatientNumberNotFoundException

service = HospitalServiceImpl()

def main():
    while True:
        print("\n--- Hospital Management System ---")
        print("1.Add patient")
        print("2.Get patient")
        print("3.Update patient")
        print("4.Delete patient")
        print("5.Add doctor")
        print("6.Get doctor")
        print("7.Update doctor")
        print("8.Delete doctor")
        print("9.Add Appointment")
        print("10. Get Appointment By ID")
        print("11. Update Appointment")
        print("12. Cancel Appointment")
        print("13. Get Appointments for Patient")
        print("14. Get Appointments for Doctor")
        print("15. Exit")

        choice = input("Enter choice: ")

        try:
            if choice == "1":
                pid = int(input("Enter Patient ID: "))
                fname = input("First Name: ")
                lname = input("Last Name: ")
                dob = input("Date of Birth (YYYY-MM-DD): ")
                gender = input("Gender: ")
                contact = input("Contact Number: ")
                address = input("Address: ")
                p = Patient(pid, fname, lname, dob, gender, contact, address)
                service.addPatient(p)
                print("Patient added successfully.")

            elif choice == "2":
                pid = int(input("Enter Patient ID: "))
                patient = service.getPatientById(pid)
                print(patient if patient else "Patient not found.")

            elif choice == "3":
                pid = int(input("Enter Patient ID to update: "))
                fname = input("First Name: ")
                lname = input("Last Name: ")
                dob = input("Date of Birth: ")
                gender = input("Gender: ")
                contact = input("Contact Number: ")
                address = input("Address: ")
                p = Patient(pid, fname, lname, dob, gender, contact, address)
                service.updatePatient(p)
                print("Patient updated successfully.")

            elif choice == "4":
                pid = int(input("Enter Patient ID to delete: "))
                service.deletePatient(pid)
                print("Patient deleted successfully.")

            elif choice == "5":
                did = int(input("Doctor ID: "))
                fname = input("First Name: ")
                lname = input("Last Name: ")
                spec = input("Specialization: ")
                contact = input("Contact Number: ")
                d = Doctor(did, fname, lname, spec, contact)
                service.addDoctor(d)
                print("Doctor added successfully.")

            elif choice == "6":
                did = int(input("Enter Doctor ID: "))
                doctor = service.getDoctorById(did)
                print(doctor if doctor else "Doctor not found.")

            elif choice == "7":
                did = int(input("Enter Doctor ID to update: "))
                fname = input("First Name: ")
                lname = input("Last Name: ")
                spec = input("Specialization: ")
                contact = input("Contact Number: ")
                d = Doctor(did, fname, lname, spec, contact)
                service.updateDoctor(d)
                print("Doctor updated successfully.")

            elif choice == "8":
                did = int(input("Enter Doctor ID to delete: "))
                service.deleteDoctor(did)
                print("Doctor deleted successfully.")

            elif choice == "9" :
                aid = int(input("Appointment ID: "))
                pid = int(input("Patient ID: "))
                did = int(input("Doctor ID: "))
                date = input("Appointment Date (YYYY-MM-DD): ")
                desc = input("Description: ")
                a = Appointment(aid, pid, did, date, desc)
                service.scheduleAppointment(a)
                print("Appointment scheduled successfully.")

            elif choice == "10":
                aid = int(input("Enter Appointment ID: "))
                a = service.getAppointmentById(aid)
                print(a if a else "Appointment not found.")

            elif choice == "11":
                aid = int(input("Appointment ID to update: "))
                pid = int(input("New Patient ID: "))
                did = int(input("New Doctor ID: "))
                date = input("New Appointment Date (YYYY-MM-DD): ")
                desc = input("New Description: ")
                a = Appointment(aid, pid, did, date, desc)
                service.updateAppointment(a)
                print("Appointment updated successfully.")

            elif choice == "12":
                aid = int(input("Appointment ID to cancel: "))
                service.cancelAppointment(aid)
                print("Appointment cancelled successfully.")

            elif choice == "13":
                pid = int(input("Patient ID: "))
                appointments = service.getAppointmentsForPatient(pid)
                for appt in appointments:
                    print(appt)

            elif choice == "14":
                did = int(input("Doctor ID: "))
                appointments = service.getAppointmentsForDoctor(did)
                for appt in appointments:
                    print(appt)

            elif choice == "15":
                print("Exiting...")
                break

            else:
                print("Invalid choice. Try again.")

        except PatientNumberNotFoundException as e:
            print(e)
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
