import pyodbc

def get_connection():
    conn_str = (
        "Driver={SQL Server};"
        "Server=LAPTOP-P3260BCS\\MSSQLSERVER01;"  # Update if different
        "Database=HMBank1;"  # Your Banking System database
        "Trusted_Connection=yes;"
    )
    try:
        return pyodbc.connect(conn_str)
    except Exception as e:
        print("Database connection failed:", e)
        return None
