from banksys.exception.insufficient_fund_exception import InsufficientFundException
from banksys.exception.invalid_account_exception import InvalidAccountException
from banksys.exception.overdraft_limit_exceeded_exception import OverdraftLimitExceededException

class CustomerServiceProviderImpl:
    def __init__(self):
        self.accounts = {}  # dict to simulate DB (key: acc_no, value: account object)

    def get_account_balance(self, account_number):
        account = self.accounts.get(account_number)
        if not account:
            raise InvalidAccountException()
        return account.balance

    def deposit(self, account_number, amount):
        account = self.accounts.get(account_number)
        if not account:
            raise InvalidAccountException()
        account.deposit(amount)
        return account.balance

    def withdraw(self, account_number, amount):
        account = self.accounts.get(account_number)
        if not account:
            raise InvalidAccountException()
        if account.account_type == "current":
            if account.balance + 1000 >= amount:  # assuming overdraft limit is 1000
                account.withdraw(amount)
            else:
                raise OverdraftLimitExceededException()
        elif account.account_type == "savings" and account.balance >= amount:
            account.withdraw(amount)
        else:
            raise InsufficientFundException()
        return account.balance

    def transfer(self, from_account_number, to_account_number, amount):
        from_acc = self.accounts.get(from_account_number)
        to_acc = self.accounts.get(to_account_number)

        if not from_acc or not to_acc:
            raise InvalidAccountException("One or both account numbers are invalid.")

        self.withdraw(from_account_number, amount)
        self.deposit(to_account_number, amount)

    def get_account_details(self, account_number):
        account = self.accounts.get(account_number)
        if not account:
            raise InvalidAccountException()
        return account
