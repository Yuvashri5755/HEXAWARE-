from banksys.dao.customer_service_provider_impl import CustomerServiceProviderImpl
from banksys.entity.account import Account

class BankServiceProviderImpl(CustomerServiceProviderImpl):
    def __init__(self, branch_name, branch_address):
        super().__init__()
        self.branch_name = branch_name
        self.branch_address = branch_address

    def create_account(self, customer, account_type, balance):
        acc = Account(account_type, balance, customer)
        self.accounts[acc.account_number] = acc
        print(f"Account created successfully. Account No: {acc.account_number}")
        return acc.account_number

    def list_accounts(self):
        return list(self.accounts.values())

    def calculate_interest(self):
        for acc in self.accounts.values():
            if acc.account_type == 'savings':
                interest = acc.calculate_interest()
                acc.balance += interest
                print(f"Interest of {interest} added to account {acc.account_number}")
