from banksys.entity.customer import Customer
from banksys.dao.bank_service_provider_impl import BankServiceProviderImpl
from banksys.exception.invalid_account_exception import InvalidAccountException
from banksys.exception.insufficient_fund_exception import InsufficientFundException
from banksys.exception.overdraft_limit_exceeded_exception import OverdraftLimitExceededException

def main():
    bank = BankServiceProviderImpl("HexaBank", "Chennai")

    while True:
        print("\n=== HM BANK SYSTEM ===")
        print("1. Create Account")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Check Balance")
        print("5. Transfer")
        print("6. Account Details")
        print("7. List All Accounts")
        print("8. Calculate Interest")
        print("9. Exit")

        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                fname = input("First Name: ")
                lname = input("Last Name: ")
                email = input("Email: ")
                phone = input("Phone Number: ")
                address = input("Address: ")
                account_type = input("Account Type (savings/current): ").lower()
                balance = float(input("Initial Balance: "))

                customer = Customer(0, fname, lname, email, phone, address)
                acc_no = bank.create_account(customer, account_type, balance)

            elif choice == '2':
                acc_no = int(input("Enter Account Number: "))
                amount = float(input("Enter Deposit Amount: "))
                new_bal = bank.deposit(acc_no, amount)
                print(f"Updated Balance: {new_bal}")

            elif choice == '3':
                acc_no = int(input("Enter Account Number: "))
                amount = float(input("Enter Withdrawal Amount: "))
                new_bal = bank.withdraw(acc_no, amount)
                print(f"Updated Balance: {new_bal}")

            elif choice == '4':
                acc_no = int(input("Enter Account Number: "))
                balance = bank.get_account_balance(acc_no)
                print(f"Current Balance: {balance}")

            elif choice == '5':
                from_acc = int(input("From Account Number: "))
                to_acc = int(input("To Account Number: "))
                amount = float(input("Amount to Transfer: "))
                bank.transfer(from_acc, to_acc, amount)
                print("Transfer Successful.")

            elif choice == '6':
                acc_no = int(input("Enter Account Number: "))
                acc = bank.get_account_details(acc_no)
                print(acc)
                print(acc.customer)

            elif choice == '7':
                accounts = bank.list_accounts()
                for acc in accounts:
                    print(acc)
                    print(acc.customer)

            elif choice == '8':
                bank.calculate_interest()

            elif choice == '9':
                print("Thank you for using HM Bank!")
                break

            else:
                print("Invalid option. Please try again.")

        except (InvalidAccountException, InsufficientFundException, OverdraftLimitExceededException) as e:
            print("Error:", e)
        except Exception as e:
            print("Unexpected error:", e)

if __name__ == "__main__":
    main()
