class OverdraftLimitExceededException(Exception):
    def __init__(self, message="Overdraft limit exceeded for this account."):
        super().__init__(message)
