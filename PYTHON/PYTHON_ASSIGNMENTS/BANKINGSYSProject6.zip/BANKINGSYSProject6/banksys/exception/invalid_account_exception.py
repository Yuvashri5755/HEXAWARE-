class InvalidAccountException(Exception):
    def __init__(self, message="Invalid account number provided."):
        super().__init__(message)
