class Account:
    last_acc_no = 1000  # static variable

    def __init__(self, account_type, balance, customer):
        Account.last_acc_no += 1
        self.account_number = Account.last_acc_no
        self.account_type = account_type
        self.balance = balance
        self.customer = customer

    def deposit(self, amount):
        self.balance += amount
        print(f"Deposited {amount}. New Balance: {self.balance}")

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
            print(f"Withdrawn {amount}. New Balance: {self.balance}")
        else:
            print("Insufficient balance")

    def calculate_interest(self):
        if self.account_type == 'savings':
            interest = self.balance * 0.045
            print(f"Interest: {interest}")
            return interest
        return 0

    def __str__(self):
        return f"Account[{self.account_number}] Type: {self.account_type}, Balance: {self.balance}"
