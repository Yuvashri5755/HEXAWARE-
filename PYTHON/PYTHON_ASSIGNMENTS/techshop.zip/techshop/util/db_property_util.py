import configparser

def get_db_properties(file_name):
    config = configparser.ConfigParser()
    config.read(file_name)
    return config['database']


