class Inventory:
    def __init__(self, inventory_id, product, quantity_in_stock, last_stock_update):
        self.inventory_id = inventory_id
        self.product = product
        self.quantity_in_stock = quantity_in_stock
        self.last_stock_update = last_stock_update

    def get_quantity_in_stock(self):
        return self.quantity_in_stock

    def add_to_inventory(self, quantity):
        self.quantity_in_stock += quantity

    def remove_from_inventory(self, quantity):
        if quantity > self.quantity_in_stock:
            raise Exception("Insufficient stock")
        self.quantity_in_stock -= quantity

    def update_stock_quantity(self, new_quantity):
        self.quantity_in_stock = new_quantity

    def is_product_available(self, quantity_to_check):
        return self.quantity_in_stock >= quantity_to_check

    def get_inventory_value(self):
        return self.product.price * self.quantity_in_stock

    def list_all_products(self):
        return f"{self.product.name} - {self.quantity_in_stock} in stock"

    def list_low_stock_products(self, threshold):
        return self.product.name if self.quantity_in_stock < threshold else None

    def list_out_of_stock_products(self):
        return self.product.name if self.quantity_in_stock == 0 else None