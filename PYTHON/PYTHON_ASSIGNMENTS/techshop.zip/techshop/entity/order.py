class Order:
    def __init__(self, order_id, customer, order_date, total_amount=0.0):
        self.order_id = order_id
        self.customer = customer
        self.order_date = order_date
        self.total_amount = total_amount
        self.status = 'Pending'

    def calculate_total_amount(self, order_details):
        self.total_amount = sum(od.calculate_subtotal() for od in order_details if od.order.order_id == self.order_id)
        return self.total_amount

    def get_order_details(self):
        return f"Order ID: {self.order_id}, Customer: {self.customer.first_name}, Date: {self.order_date}, Total: {self.total_amount}"

    def update_order_status(self, new_status):
        self.status = new_status

    def cancel_order(self):
        self.status = 'Cancelled'