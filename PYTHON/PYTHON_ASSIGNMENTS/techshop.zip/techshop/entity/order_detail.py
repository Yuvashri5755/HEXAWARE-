class OrderDetail:
    def __init__(self, order_detail_id, order, product, quantity):
        self.order_detail_id = order_detail_id
        self.order = order
        self.product = product
        self.quantity = quantity

    def calculate_subtotal(self):
        return self.quantity * self.product.price

    def get_order_detail_info(self):
        return f"{self.product.name} x {self.quantity} = {self.calculate_subtotal()}"

    def update_quantity(self, quantity):
        if quantity < 1:
            raise ValueError("Quantity must be at least 1")
        self.quantity = quantity
