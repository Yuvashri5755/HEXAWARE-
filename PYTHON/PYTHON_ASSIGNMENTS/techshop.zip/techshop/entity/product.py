class Product:
    def __init__(self, product_id, name, description, price):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price

    def get_product_details(self):
        return f"{self.name}: {self.description}, Price: {self.price}"

    def update_product_info(self, price=None, description=None):
        if price is not None:
            if price < 0:
                raise ValueError("Price cannot be negative")
            self.price = price
        if description:
            self.description = description