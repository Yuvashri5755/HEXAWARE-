
from techshop.entity.customer import Customer
from techshop.dao.customer_dao import CustomerDAO
from techshop.dao.product_dao import ProductDAO
from techshop.dao.order_dao import OrderDAO
from techshop.entity.product import Product
from techshop.entity.order import Order
from datetime import date

def main():
    while True:
        print("TechShop Management System")
        print("1. Add New Customer")
        print("2. View All Customers")
        print("3. Add Product")
        print("4. View All Products")
        print("5. Place New Order")
        print("6. View All Orders")
        print("7. Exit")

        choice = input("Enter choice: ")

        if choice == '1':
            fname = input("First Name: ")
            lname = input("Last Name: ")
            email = input("Email: ")
            phone = input("Phone: ")
            address = input("Address: ")
            cust = Customer(None, fname, lname, email, phone, address)
            dao = CustomerDAO()
            dao.insert_customer(cust)
            print("Customer added successfully!")

        elif choice == '2':
            dao = CustomerDAO()
            customers = dao.get_all_customers()
            for c in customers:
                print(c)

        elif choice == '3':
            name = input("Product Name: ")
            desc = input("Description: ")
            price = float(input("Price: "))
            product = Product(None, name, desc, price)
            dao = ProductDAO()
            dao.insert_product(product)
            print("Product added successfully!")

        elif choice == '4':
            dao = ProductDAO()
            products = dao.get_all_products()
            for p in products:
                print(p)

        elif choice == '5':
            customer_id = int(input("Customer ID: "))
            total_amount = float(input("Total Amount: "))
            customer = Customer(customer_id, '', '', '', '', '')
            order = Order(None, customer, date.today(), total_amount)
            order_dao = OrderDAO()
            order_dao.insert_order(order)
            print("Order placed successfully!")

        elif choice == '6':
            order_dao = OrderDAO()
            orders = order_dao.get_all_orders()
            for o in orders:
                print(o)

        elif choice == '7':
            print("Exiting TechShop System. Thank You!")
            break
        else:
            print("Invalid choice")



if __name__ == '__main__':
    main()
