class InsufficientStockException(Exception):
    def __init__(self, message="Insufficient stock available"):
        super().__init__(message)
