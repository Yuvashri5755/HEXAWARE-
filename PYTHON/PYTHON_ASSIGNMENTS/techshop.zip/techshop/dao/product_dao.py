from techshop.entity.product import Product
from techshop.util.db_conn_util import get_connection

class ProductDAO:
    def insert_product(self, product: Product):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Products (ProductName, Description, Price)
            VALUES (?, ?, ?)
        """, (product.name, product.description, product.price))
        conn.commit()
        conn.close()

    def get_all_products(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Products")
        result = cursor.fetchall()
        conn.close()
        return result