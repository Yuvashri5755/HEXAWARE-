from techshop.entity.customer import Customer
from techshop.util.db_conn_util import get_connection

class CustomerDAO:
    def insert_customer(self, customer: Customer):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Customers (FirstName, LastName, Email, Phone, Address)
            VALUES (?, ?, ?, ?, ?)
        """, (customer.first_name, customer.last_name, customer.email, customer.phone, customer.address))
        conn.commit()
        conn.close()

    def get_all_customers(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Customers")
        result = cursor.fetchall()
        conn.close()
        return result
