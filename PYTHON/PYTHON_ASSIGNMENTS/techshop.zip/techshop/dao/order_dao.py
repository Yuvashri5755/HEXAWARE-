from techshop.entity.order import Order
from techshop.util.db_conn_util import get_connection

class OrderDAO:
    def insert_order(self, order: Order):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
                       INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, Status)
                       VALUES (?, ?, ?, ?)
                       """, (
                           order.customer.customer_id,
                           order.order_date.strftime('%Y-%m-%d'),
                           order.total_amount,
                           order.status
                       ))
        conn.commit()
        conn.close()

    def get_all_orders(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Orders")
        result = cursor.fetchall()
        conn.close()
        return result
