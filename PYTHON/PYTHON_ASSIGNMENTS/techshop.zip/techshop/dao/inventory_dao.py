from techshop.entity.inventory import Inventory
from techshop.util.db_conn_util import get_connection

class InventoryDAO:
    def update_inventory(self, inventory: Inventory):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE Inventory
            SET QuantityInStock = ?, LastStockUpdate = ?
            WHERE ProductID = ?
        """, (inventory.quantity_in_stock, inventory.last_stock_update, inventory.product.product_id))
        conn.commit()
        conn.close()

    def get_inventory_by_product_id(self, product_id):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Inventory WHERE ProductID = ?", (product_id,))
        result = cursor.fetchone()
        conn.close()
        return result